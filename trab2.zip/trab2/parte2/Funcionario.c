#include "Funcionario.h"

    

//Testa o programa de acordo com a especificação.
//Faz todas as verificações de erros necessárias
int testa_programa(){
    pthread_t th[20]; //0 a 9 corintinanos 10 a 19 palmeirenses

    pthread_mutex_init(&mutex_banheiro, NULL);
    pthread_cond_init(&cond_banheiro, NULL);
   

    //Criar todas as threads
    for(int i = 0; i < 20; i++){
        int* id = malloc(sizeof(int));
        *id = i;
        if(i < 10){
            *id = 1 + i; //para ficar com id de 1 a 10
            if(pthread_create(&th[i], NULL, &thread_corintiano, id) != 0){
                fprintf(stderr, "Erro ao criar thread %d\n", i);
                return 1;
            }
        }
        else{
            *id = *id - 10 + 1;   //conta basica para ficar com id de 1 a 10
            if(pthread_create(&th[i], NULL, &thread_palmeirense, id) != 0){
                fprintf(stderr, "Erro ao criar thread %d\n", i);
                return 2;
            }
        }
    }

    //Esperar todas as threads acabarem
    for(int i = 0; i < 20; i++){
        if(pthread_join(th[i], NULL) != 0){
            fprintf(stderr, "Error ao fazer join na thread %d\n", i);
            return 3;
        }
    }

    pthread_mutex_destroy(&mutex_banheiro);
    pthread_cond_destroy(&cond_banheiro);
   
    return 0;
}

void* thread_corintiano(void* arg){
    int* id = (int*)arg;
    //cada corintiano e palmeirense tera um identificador de 1 a 10
    //while(1){
        corintianoQuerEntrar();
        printf ("Eu sou corintiano-%d: ... UFA! Entrei no banheiro!\n",*id);
        sleep(3);
        //printf("Eu sou corintiano-%d: ... Estou aliviado! Vou trabalhar!\n",*id);
        corintianoSai();
        printf("Eu sou corintiano-%d: ... Estou aliviado! Vou trabalhar!\n",*id);
        sleep(5);
    //}
    free(arg);
}

void* thread_palmeirense(void* arg){
    int* id = (int*)arg;
    //cada corintiano e palmeirense tera um identificador de 1 a 10
    //while(1){
        palmeirenseQuerEntrar();
        printf ("Eu sou palmeirense-%d: ... UFA! Entrei no banheiro!\n",*id);
        sleep(3);
        //printf ("Eu sou palmeirense-%d: ... Estou aliviado! Vou trabalhar!\n",*id);
        palmeirenseSai();
        printf ("Eu sou palmeirense-%d: ... Estou aliviado! Vou trabalhar!\n",*id);
        sleep(5);
    //}
    free(arg);
}