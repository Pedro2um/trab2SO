#ifndef MONITOR_BANHEIRO
#define MONITOR_BANHEIRO

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <string.h>

#define CAPACIDADE_BANHEIRO 3
#define PALMEIRENSE -1
#define CORINTIANO 1
#define NENHUM 0



//não é boa prática, mas não faz mal nesse contexto
pthread_mutex_t mutex_banheiro;
pthread_mutex_t mutex_time;
pthread_cond_t cond_banheiro;
pthread_cond_t cond_time;
//pthread_cond_t cond_banheiro_palmeirense;

void corintianoQuerEntrar();
void corintianoSai();
void palmeirenseQuerEntrar();
void palmeirenseSai();

#endif