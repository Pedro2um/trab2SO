#include "MonitorBanheiro.h"

    
    
    


/*  TODO:
    A sede desta empresa possui apenas um banheiro, no qual cabem no máximo três pessoas. 
    De acordo com as regras estabelecidas pela empresa, para não dar confusão, o banheiro
    só pode ser ocupado por pessoas que torcem para o mesmo time. Uma pessoa, ao tentar entrar
    no banheiro, ficará esperando se o banheiro estiver ocupado por pessoas do time oposto ou se ele
    estiver lotado. Sempre que houver um corintiano na fila, ela terá preferência sobre os palmeirenses para entrar no banheiro (hehehe).
*/

/*  IMPORTANTE:
    quando uma thread fica bloqueada (seja porque o banheiro está ocupado por pessoas do time oposto ao seu, 
    seja porque ele está lotado) usar para isto variáveis de condição.
*/

int qtd_banheiro = 0;
int torcedor = NENHUM;
//funcionando para qtd de pessoas no banheiro
//TODO:
// 1 - Não deixar torcedores de times diferentes ao mesmo tempo no banheiro
// 2 - Colocar prioridade de corintianos maior que palmeirenses

void corintianoQuerEntrar(){
    pthread_mutex_lock(&mutex_banheiro);
    while(qtd_banheiro == CAPACIDADE_BANHEIRO || torcedor == PALMEIRENSE){
        if(qtd_banheiro == CAPACIDADE_BANHEIRO ) pthread_cond_wait(&cond_banheiro, &mutex_banheiro);
        if(torcedor == PALMEIRENSE) pthread_cond_wait(&cond_banheiro, &mutex_banheiro);
    }
    //entrou
    qtd_banheiro++;
    torcedor = CORINTIANO;
    //printf("no corintinano quer entrar : %d\n", qtd_banheiro); //usado para saber quantos estão no banheiro
    pthread_mutex_unlock(&mutex_banheiro);
}

void corintianoSai(){
    pthread_mutex_lock(&mutex_banheiro);
    //saiu
    qtd_banheiro--;

    if(qtd_banheiro < CAPACIDADE_BANHEIRO) {
        pthread_cond_broadcast(&cond_banheiro);
    }
    
    if(qtd_banheiro == 0){
        torcedor = NENHUM;
        pthread_cond_broadcast(&cond_banheiro);
    }

    //printf("no corintinano sai : %d\n", qtd_banheiro); //usado para saber quantos estão no banheiro
    pthread_mutex_unlock(&mutex_banheiro);
}


void palmeirenseQuerEntrar(){
    pthread_mutex_lock(&mutex_banheiro);
    while(qtd_banheiro == CAPACIDADE_BANHEIRO || torcedor == CORINTIANO){
        if(qtd_banheiro == CAPACIDADE_BANHEIRO ) pthread_cond_wait(&cond_banheiro, &mutex_banheiro);
        if(torcedor == CORINTIANO) pthread_cond_wait(&cond_banheiro, &mutex_banheiro);
    }
    qtd_banheiro++;
    torcedor = PALMEIRENSE;
    //printf("no palmeirense quer entrar : %d\n", qtd_banheiro); //usado para saber quantos estão no banheiro
    pthread_mutex_unlock(&mutex_banheiro);
}
void palmeirenseSai(){
    pthread_mutex_lock(&mutex_banheiro);
    //saiu
    qtd_banheiro--;

    if(qtd_banheiro < CAPACIDADE_BANHEIRO) {
        pthread_cond_broadcast(&cond_banheiro);
    }

    if(qtd_banheiro == 0){
        torcedor = NENHUM;
        pthread_cond_broadcast(&cond_banheiro);
    }

    //printf("no palmeirense sai : %d\n", qtd_banheiro); //usado para saber quantos estão no banheiro
    pthread_mutex_unlock(&mutex_banheiro);
}