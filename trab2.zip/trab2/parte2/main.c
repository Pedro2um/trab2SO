#include "Funcionario.h"

int main(){
    return testa_programa();
}