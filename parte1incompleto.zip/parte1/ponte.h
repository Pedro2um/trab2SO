#ifndef PONTE
#define PONTE

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <string.h>
#include <semaphore.h>


//não é boa prática, mas não faz mal nesse caso
sem_t macaco_sem; //controlar capacidade
sem_t gorila_sem; //binário, afinal só pode ter 1 gorila por vez atravessando

void macacoQuerAtravessar();
void macacoSai(); //saiu da ponte
void gorilaQuerAtravessar();
void gorilaSai(); //saiu da ponte

#endif