#include "ponte.h"




void macacoQuerAtravessar(){

}

void macacoSai(){

}

void gorilaQuerAtravessar(){
   
}

void gorilaSai(){
    
}