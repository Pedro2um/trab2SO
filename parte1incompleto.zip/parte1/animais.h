#ifndef ANIMAIS
#define ANIMAIS

#include "ponte.h"

#define MAX_ANIMAIS 10

#define MAX_MACACOS 10

int testa_macacos(); //retorna 0, caso seja bem sucessida, ou um valor !=0 , um código de erro
void* thread_macaco(void* arg);
void* thread_gorila(void* arg);

#endif