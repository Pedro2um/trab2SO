#include "animais.h"

int testa_macacos(){
    pthread_t th[MAX_MACACOS]; // 0 a 9 são macacos, 10 e 11 são gorilas (adicionar depois)

    sem_init(&macaco_sem, 0, MAX_MACACOS);

    for(int i = 0; i < MAX_MACACOS; i++){
        int* id = malloc(sizeof(int));
        *id = 1 + i; //para ficar com id de 1 a 10
        if(pthread_create(&th[i], NULL, &thread_macaco, id) != 0){
            fprintf(stderr, "Erro ao criar thread %d\n", i);
            return 1;
        }
        
    }

    //Esperar todas as threads acabarem
    for(int i = 0; i < MAX_MACACOS; i++){
        if(pthread_join(th[i], NULL) != 0){
            fprintf(stderr, "Error ao fazer join na thread %d\n", i);
            return 3;
        }
    }

    sem_destroy(&macaco_sem);
}

void* thread_macaco(void* arg){
    int* id = (int*)arg;
    //while(1){
        macacoQuerAtravessar();
        printf("Eu sou macaco-%d: ... Estou atravessando a ponte!\n",*id);
        sleep(3);
    
        macacoSai();
        printf("Eu sou macaco-%d: ... Atravessei a ponte!\n",*id);
        sleep(5);
    //}
    free(arg);
}

void* thread_gorila(void* arg){
    int* id = (int*)arg;
    
    //while(1){
        gorilaQuerAtravessar();
        printf ("Eu sou gorila-%d: ... Atravessei a ponte!\n",*id);
        sleep(3);
        
        gorilaSai();
        printf("Eu sou gorila-%d: ... Atravessei a ponte!\n",*id);
        sleep(5);
    //}
    free(arg);
}