#include "animais.h"

int main() {    
    return testa_macacos();
}