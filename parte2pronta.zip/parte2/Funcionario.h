#ifndef FUNCIONARIO
#define FUNCIONARIO

#include "MonitorBanheiro.h"


int testa_programa(); //retorna 0, caso seja bem sucessida, ou um valor !=0 , um código de erro
void* thread_corintiano(void* arg);
void* thread_palmeirense(void* arg);

#endif