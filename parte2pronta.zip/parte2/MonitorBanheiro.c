#include "MonitorBanheiro.h"

    
    
    


/*  TODO:
    A sede desta empresa possui apenas um banheiro, no qual cabem no máximo três pessoas. 
    De acordo com as regras estabelecidas pela empresa, para não dar confusão, o banheiro
    só pode ser ocupado por pessoas que torcem para o mesmo time. Uma pessoa, ao tentar entrar
    no banheiro, ficará esperando se o banheiro estiver ocupado por pessoas do time oposto ou se ele
    estiver lotado. Sempre que houver um corintiano na fila, ela terá preferência sobre os palmeirenses para entrar no banheiro (hehehe).
*/

/*  IMPORTANTE:
    quando uma thread fica bloqueada (seja porque o banheiro está ocupado por pessoas do time oposto ao seu, 
    seja porque ele está lotado) usar para isto variáveis de condição.
*/

int qtd_banheiro = 0;
int torcedor = NENHUM;
//funcionando para qtd de pessoas no banheiro
//TODO:
// 2 - Colocar prioridade de corintianos maior que palmeirenses
void corintianoQuerEntrar() {
    pthread_mutex_lock(&mutex_banheiro);

    while ((qtd_banheiro == CAPACIDADE_BANHEIRO || (qtd_banheiro > 0 && torcedor == PALMEIRENSE))) {
        pthread_cond_wait(&cond_corintiano, &mutex_banheiro);
    }

    // Entrou
    qtd_banheiro++;
    torcedor = CORINTIANO;
    //printf("no corintiano quer entrar : %d\n", qtd_banheiro);

    pthread_mutex_unlock(&mutex_banheiro);
}

void corintianoSai() {
    pthread_mutex_lock(&mutex_banheiro);

    // Saiu
    qtd_banheiro--;

    if (qtd_banheiro < CAPACIDADE_BANHEIRO) {
        pthread_cond_broadcast(&cond_corintiano);
    }

    if (qtd_banheiro == 0) {
        torcedor = NENHUM;
        pthread_cond_broadcast(&cond_palmeirense);
    }

    //printf("no corintiano sai : %d\n", qtd_banheiro);

    pthread_mutex_unlock(&mutex_banheiro);
}

void palmeirenseQuerEntrar() {
    pthread_mutex_lock(&mutex_banheiro);

    while ((qtd_banheiro == CAPACIDADE_BANHEIRO || (qtd_banheiro > 0 && torcedor == CORINTIANO))) {
        pthread_cond_wait(&cond_palmeirense, &mutex_banheiro);
    }

    // Entrou
    qtd_banheiro++;
    torcedor = PALMEIRENSE;
    //printf("no palmeirense quer entrar : %d\n", qtd_banheiro);

    pthread_mutex_unlock(&mutex_banheiro);
}

void palmeirenseSai() {
    pthread_mutex_lock(&mutex_banheiro);

    // Saiu
    qtd_banheiro--;

    if (qtd_banheiro < CAPACIDADE_BANHEIRO) {
        pthread_cond_broadcast(&cond_palmeirense);
    }

    if (qtd_banheiro == 0) {
        torcedor = NENHUM;
        pthread_cond_broadcast(&cond_corintiano);
    }

    //printf("no palmeirense sai : %d\n", qtd_banheiro);

    pthread_mutex_unlock(&mutex_banheiro);
}